#pragma once

#include "..\common.h"

#include "assemble.h"
#include "option.h"

void ToMachineCode(const SPackAsm* pack_asm, const SOption* option);
