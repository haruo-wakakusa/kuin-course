#pragma once

#include "..\common.h"

// 'dbg'
EXPORT void _dbgPrint(const U8* str);
