// Hash with SHA-256.

#pragma once

#include "..\common.h"

EXPORT void* _hash(const U8* data);
