#pragma once

#include "..\common.h"

EXPORT void _print(const U8* str);
EXPORT void* _input(void);
