#pragma once

#include "..\common.h"

EXPORT void _init(void* heap, S64* heap_cnt, S64 app_code, const U8* use_res_flags);
EXPORT void _fin(void);
