#pragma once

#include "..\common.h"

void* DecodeBc(size_t size, const void* data, int* width, int* height);
