#pragma once

#include "..\common.h"

void* DecodeJpg(size_t size, const void* data, int* width, int* height);
