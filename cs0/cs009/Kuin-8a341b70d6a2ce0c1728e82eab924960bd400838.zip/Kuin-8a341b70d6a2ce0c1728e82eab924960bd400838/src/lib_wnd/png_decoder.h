#pragma once

#include "..\common.h"

void* DecodePng(size_t size, const void* data, int* width, int* height);
